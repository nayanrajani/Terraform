package main

import (
	"github.com/cloudflare/cf-terraforming/internal/app/cf-terraforming/cmd"
)

func main() {
	cmd.Execute()
}
